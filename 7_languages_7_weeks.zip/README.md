# 7 Modern Languages in 7 Weeks — Spatial Data Focus

Welcome! This repository documents my journey learning 7 modern programming languages over 7 weeks, with a focus on cartography, spatial analysis, and data visualization.

See individual folders for weekly progress.