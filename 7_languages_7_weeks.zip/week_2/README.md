# Week 2

Daily progress files and code go here.