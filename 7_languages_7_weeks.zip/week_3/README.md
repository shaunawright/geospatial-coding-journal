# Week 3

Daily progress files and code go here.