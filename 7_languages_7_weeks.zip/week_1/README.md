# Week 1

Daily progress files and code go here.